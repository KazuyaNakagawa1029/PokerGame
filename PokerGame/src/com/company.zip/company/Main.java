package com.company;

public class Main {
    public static void main(String[] args) {
        PorckerGame pg = new PorckerGame();
        pg.Begin();
    }
}

